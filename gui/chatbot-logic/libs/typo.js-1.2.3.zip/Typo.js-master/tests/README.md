These tests can be run by loading the entire Typo.js project as a Chrome 
extension and then clicking the Typo.js Testing Harness icon in the browser.
A manifest.json file is included in the project root to make this as easy
as possible.