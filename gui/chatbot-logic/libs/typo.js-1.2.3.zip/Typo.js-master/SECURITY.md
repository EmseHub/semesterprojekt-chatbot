## Reporting a Vulnerability

Please report security vulnerabilities to **[cfinke@gmail.com](mailto:cfinke@gmail.com)**. I will respond as quickly as possible.
